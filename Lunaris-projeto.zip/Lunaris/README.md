# Lunaris Alpha 0.1
Toda luz tem seu começo.

Protótipo Android Kotlin/Compose, dados locais. Sem comunidade online, pagamentos, autenticação ou moderação. Compilação ainda não validada. Identificador Android anterior mantido.

## Beta 1.0
Atualização visual incremental Celestial Witch: paleta, contraste, cartões, navegação, diário e comunidade. Sem mudanças nas regras Firebase. Compilação Android pendente.
