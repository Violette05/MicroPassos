package com.micropassos.app

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.auth.FirebaseAuth

@Composable internal fun Community(uid:String,name:String,bio:String) {
 val db=remember { FirebaseFirestore.getInstance() }
 val posts=db.collection("posts")
 val blocks=db.collection("users").document(uid).collection("blocks")
 var feed by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
 var blocked by remember { mutableStateOf<Set<String>>(emptySet()) }
 var body by remember { mutableStateOf("") }
 var status by remember { mutableStateOf("") }
 var busy by remember { mutableStateOf(false) }
 var ready by remember { mutableStateOf(false) }
 DisposableEffect(uid) {
  val a=posts.orderBy("createdAt",Query.Direction.DESCENDING).limit(30).addSnapshotListener { snap,err -> if(err!=null) status="Feed indisponível." else feed=snap?.documents.orEmpty() }
  val b=blocks.addSnapshotListener { snap,err -> ready=err==null; if(err==null) blocked=snap?.documents.orEmpty().map{it.id}.toSet() else status="Não foi possível carregar bloqueios." }
  onDispose { a.remove(); b.remove() }
 }
 Text("✧ Entre Nós",style=MaterialTheme.typography.headlineSmall,color=MaterialTheme.colorScheme.primary);Text("Comunidade de teste")
 SocialPanel(uid,name,bio,blocked)
 Text("Publicações são visíveis a contas verificadas. Não compartilhe dados sensíveis. Teste apenas com adultos convidados.")
 OutlinedTextField(body,{if(it.length<=1000)body=it},label={Text("Novo Fragmento")},modifier=Modifier.fillMaxWidth())
 Button(enabled=!busy && body.isNotBlank() && name.isNotBlank(),onClick={busy=true;posts.add(mapOf("uid" to uid,"name" to name.take(80),"bio" to bio.take(160),"body" to body.trim(),"createdAt" to FieldValue.serverTimestamp())).addOnCompleteListener{busy=false;if(it.isSuccessful){body="";status="Fragmento publicado."}else status="Não foi possível publicar."}}){Text("Publicar Fragmento")}
 Text(status)
 if(ready) feed.filter{it.getString("uid") !in blocked}.forEach { post -> key(post.id) {
  val author=post.getString("uid") ?: ""
  val ref=posts.document(post.id)
  var likes by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
  var comments by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
  var open by remember { mutableStateOf(false) }
  var profile by remember { mutableStateOf(false) }
  var comment by remember { mutableStateOf("") }
  var pending by remember { mutableStateOf(false) }
  DisposableEffect(post.id) { val l=ref.collection("likes").addSnapshotListener{s,e->if(e==null)likes=s?.documents.orEmpty()};onDispose{l.remove()} }
  if(open) DisposableEffect(post.id) {val l=ref.collection("comments").orderBy("createdAt").limit(50).addSnapshotListener{s,e->if(e==null)comments=s?.documents.orEmpty()};onDispose{l.remove()}}
  OutlinedCard(Modifier.fillMaxWidth(),colors=CardDefaults.outlinedCardColors(containerColor=MaterialTheme.colorScheme.surface)) { Column(Modifier.padding(12.dp)) {
   TextButton(onClick={profile=!profile}){Text(post.getString("name") ?: "Lunaris")}
   if(profile){Text(post.getString("bio") ?: "");Text("Fragmentos recentes deste perfil");feed.filter{it.getString("uid")==author}.forEach{Text(it.getString("body") ?: "")}}
   Text(post.getString("body") ?: "")
   Row { TextButton(enabled=!pending,onClick={pending=true;val like=ref.collection("likes").document(uid);val task=if(likes.any{it.id==uid})like.delete() else like.set(mapOf("uid" to uid));task.addOnCompleteListener{pending=false;if(!it.isSuccessful)status="Não foi possível atualizar curtida."}}){Text("${if(likes.any{it.id==uid}) "♥" else "♡"} ${likes.size}")};TextButton(onClick={open=!open}){Text("Comentários")} }
   if(open){comments.filter{it.getString("uid") !in blocked}.forEach{c->Text("${c.getString("name")}: ${c.getString("body")}");if(c.getString("uid")==uid)TextButton(onClick={c.reference.delete().addOnFailureListener{status="Falha ao excluir."}}){Text("Excluir comentário")}};OutlinedTextField(comment,{if(it.length<=500)comment=it},label={Text("Comentar")});Button(enabled=comment.isNotBlank()&&!pending,onClick={pending=true;ref.collection("comments").add(mapOf("uid" to uid,"name" to name.take(80),"body" to comment.trim(),"createdAt" to FieldValue.serverTimestamp())).addOnCompleteListener{pending=false;if(it.isSuccessful)comment="" else status="Falha ao comentar."}}){Text("Enviar")}}
   if(author==uid)TextButton(onClick={ref.delete().addOnFailureListener{status="Falha ao excluir."}}){Text("Excluir publicação")} else {TextButton(onClick={db.collection("reports").document("${post.id}_$uid").set(mapOf("uid" to uid,"postId" to post.id,"createdAt" to FieldValue.serverTimestamp())).addOnCompleteListener{status=if(it.isSuccessful)"Denúncia enviada para revisão manual." else "Falha ao denunciar."}}){Text("Denunciar")};TextButton(onClick={blocks.document(author).set(mapOf("uid" to author)).addOnFailureListener{status="Falha ao ocultar."}}){Text("Ocultar autor")}}
  }}
 }}
 if(blocked.isNotEmpty()) TextButton(onClick={blocked.forEach{blocks.document(it).delete()}}){Text("Desfazer todos os bloqueios locais do feed")}
}
