package com.micropassos.app

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

@Composable internal fun OnlineGate(context: Context) {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var guest by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var verified by remember { mutableStateOf(auth.currentUser?.isEmailVerified == true) }
    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { user = it.currentUser; verified = it.currentUser?.isEmailVerified == true }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }
    val current = user
    if (guest || (current != null && verified)) {
        key(if(guest) "guest" else current?.uid) {
            Lunaris(context, if(guest) null else current?.uid) {
                if(guest) {
                    Text("Modo local. Seus registros não são enviados à nuvem.")
                    TextButton(onClick={guest=false;message=""}) { Text("Entrar em uma conta") }
                } else if(current != null) {
                    val prefs = remember(current.uid) { context.getSharedPreferences("lunaris_account_${current.uid}", Context.MODE_PRIVATE) }
                    Text("Conta: ${current.email ?: ""}")
                    Text("Sincronização manual do nome, pronome e biografia.")
                    Button(enabled=!busy,onClick={busy=true;db.collection("users").document(current.uid).set(mapOf("name" to (prefs.getString("name", "") ?: ""),"pronoun" to (prefs.getString("pronoun", "") ?: ""),"bio" to (prefs.getString("bio", "") ?: ""))).addOnCompleteListener{busy=false;message=if(it.isSuccessful) "Perfil enviado." else "Não foi possível enviar o perfil."}}){Text("Enviar perfil à nuvem")}
                    var refresh by remember { mutableStateOf(false) }
                    Button(enabled=!busy,onClick={busy=true;db.collection("users").document(current.uid).get().addOnCompleteListener{task->busy=false;val doc=if(task.isSuccessful) task.result else null;if(doc!=null && doc.exists()){prefs.edit().putString("name",doc.getString("name") ?: "").putString("pronoun",doc.getString("pronoun") ?: "").putString("bio",doc.getString("bio") ?: "").apply();refresh=true;message="Perfil recebido. Reabra o aplicativo para visualizar."}else message="Perfil indisponível."}}){Text("Baixar perfil da nuvem")}
                    Text(message)
                    TextButton(enabled=!busy,onClick={auth.signOut();password="";message=""}){Text("Sair da conta")}
                }
            }
        }
    } else {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF100C1D),Color(0xFF302047),Color(0xFF100C1D)))).imePadding().verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.lunar_scene),null,Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(24.dp)),contentScale=ContentScale.Crop)
            Text("✧   ☾   ✧",color=Color(0xFFDFC28A),fontSize=30.sp)
            Text("L U N A R I S",color=Color(0xFFDFC28A),fontFamily=FontFamily.Serif,fontSize=32.sp)
            Text("Toda luz tem seu começo.",color=Color(0xFFE8D5F5),textAlign=TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            if(current!=null){
                Text("Confirme seu e-mail antes de continuar.")
                Button(enabled=!busy,onClick={busy=true;current.sendEmailVerification().addOnCompleteListener{busy=false;message=if(it.isSuccessful) "E-mail enviado. Confira sua caixa de entrada." else "Não foi possível enviar. Tente mais tarde."}}){Text("Enviar confirmação")}
                Button(enabled=!busy,onClick={busy=true;current.reload().addOnCompleteListener{busy=false;verified=it.isSuccessful && current.isEmailVerified;message=if(verified) "E-mail confirmado." else "Confirmação ainda pendente."}}){Text("Já confirmei")}
                TextButton(onClick={auth.signOut();message=""}){Text("Sair")}
            } else {
                OutlinedTextField(email,{email=it},modifier=Modifier.fillMaxWidth(),label={Text("E-mail")},singleLine=true,shape=RoundedCornerShape(16.dp),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Email))
                OutlinedTextField(password,{password=it},modifier=Modifier.fillMaxWidth(),label={Text("Senha")},singleLine=true,shape=RoundedCornerShape(16.dp),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Password),visualTransformation=if(showPassword) VisualTransformation.None else PasswordVisualTransformation(),trailingIcon={TextButton(onClick={showPassword=!showPassword}){Text(if(showPassword) "Ocultar" else "Mostrar")}})
                Button(modifier=Modifier.fillMaxWidth().heightIn(min=48.dp),enabled=!busy && email.isNotBlank() && password.length>=6,onClick={busy=true;auth.signInWithEmailAndPassword(email.trim(),password).addOnCompleteListener{busy=false;message=if(it.isSuccessful) "" else "Não foi possível entrar. Confira seus dados.";if(it.isSuccessful)password=""}}){Text("Entrar")}
                OutlinedButton(modifier=Modifier.fillMaxWidth().heightIn(min=48.dp),enabled=!busy && email.isNotBlank() && password.length>=6,onClick={busy=true;auth.createUserWithEmailAndPassword(email.trim(),password).addOnCompleteListener{busy=false;message=if(it.isSuccessful) "Conta criada. Confirme seu e-mail." else "Não foi possível criar a conta.";if(it.isSuccessful)password=""}}){Text("Criar conta de teste")}
                TextButton(enabled=!busy && email.isNotBlank(),onClick={busy=true;auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener{busy=false;message="Se a conta existir, confira seu e-mail para recuperar a senha."}}){Text("Esqueci minha senha")}
                TextButton(enabled=!busy,onClick={guest=true;message=""}){Text("Continuar no modo local")}
            }
            if(busy) { CircularProgressIndicator(); Text("Aguarde um instante…") }
            if(message.isNotBlank()) Text(message,color=Color(0xFFE8D5F5),textAlign=TextAlign.Center)
            Text("Alpha familiar • Use contas de teste, sem dados sensíveis.",color=Color(0xFFB9A8D0),fontSize=12.sp,textAlign=TextAlign.Center)
        }
    }
}
